
/*
 * gameknot_applet_cb.c: callback functions.
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "gameknot_applet.h"

#include <glade/glade.h>
#include <gconf/gconf-client.h>
#include <panel-applet-gconf.h>

gint
timer_cb(GKapplet *GK)
{
  gchar *s;
  gameknot_get_time(GK);
  GK->prev_games = GK->games;
  
  if (GK->hours == TIME_UNKNOWN)
    s = g_strdup(_("Can't connect"));
  else if (GK->hours == TIME_WRONG)
    s = g_strdup(_("Wrong password?"));
  else if (GK->hours == TIME_NOPLAY)
    s = g_strdup_printf(_("%s - No games to play"), GK->userid);
  else
    {
      gchar *tmp;
      format_time_string(&tmp, GK->hours);
      if (GK->games == 1)
        s = g_strdup_printf(_("%s - 1 game to move\n%s"), GK->userid, tmp);
      else
        s = g_strdup_printf(_("%s - %d games to move\n%s"), GK->userid, GK->games, tmp);
      g_free(tmp);
    }
  
  gtk_label_set_text(GTK_LABEL(GK->label), s);
  gtk_tooltips_set_tip(GK->tooltips, GTK_WIDGET(GK->applet), s, NULL);
  set_image(GK);
#if HAVE_LIBNOTIFY
  notify(GK);
#endif
  g_free(s);
  return TRUE;
}

void
preferences_cb (BonoboUIComponent *uic, GKapplet *GK, const gchar *verbname)
{
  GladeXML *xml;
  gchar *glade_file;

  if (GK->prefs != NULL)
    {
      gtk_window_present(GTK_WINDOW(GK->prefs));
      return;
    }
  
  glade_file = g_build_filename(GLADEDIR, "gameknot_applet.glade", NULL);
  xml = glade_xml_new (glade_file, "prefs_dialog", NULL);

  GK->prefs = glade_xml_get_widget(xml, "prefs_dialog");
  //  if (GK->prefs_icon == NULL)
  //    GK->prefs_icon = gdk_pixbuf_new_from_file_at_size(DATADIR"icons/hicolor/scalable/apps/gameknot_applet.svg", 64, 64, NULL);
  //  printf("%p\n", GK->prefs_icon);
  //  gtk_window_set_icon(GTK_WINDOW(GK->prefs), GK->prefs_icon);

  GK->entUsr = glade_xml_get_widget(xml, "entUsr");
  GK->entPwd = glade_xml_get_widget(xml, "entPwd");
  GK->spTime = glade_xml_get_widget(xml, "spTime");
  GK->cbApp = glade_xml_get_widget(xml, "cbApp");
  GK->spMax = glade_xml_get_widget(xml, "spMax");
  GK->chkTime = glade_xml_get_widget(xml, "chkTime");
  GK->spHours = glade_xml_get_widget(xml, "spHours");
  GK->chkGames = glade_xml_get_widget(xml, "chkGames");

  gtk_entry_set_text(GTK_ENTRY(GK->entUsr), GK->userid);
  gtk_entry_set_text(GTK_ENTRY(GK->entPwd), GK->passwd);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(GK->spTime), GK->refresh_time);
  gtk_combo_box_set_active(GTK_COMBO_BOX(GK->cbApp), GK->appareance);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(GK->spMax), GK->max_days);
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(GK->chkTime), GK->not_time);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(GK->spHours), GK->not_hours);
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(GK->chkGames), GK->not_games);

#if !HAVE_LIBNOTIFY
  gtk_widget_set_sensitive(GK->chkTime, FALSE);
  gtk_widget_set_sensitive(GK->spHours, FALSE);
  gtk_widget_set_sensitive(GK->chkGames, FALSE);
#endif
  
  g_free (glade_file);
  g_object_unref (xml);

  g_signal_connect_swapped(G_OBJECT(GK->prefs), "response",
                            G_CALLBACK(prefs_response_cb),
                            (gpointer)GK);
  g_signal_connect(G_OBJECT(GK->cbApp), "changed",
                          G_CALLBACK(prefs_app_cb),
                          (gpointer)GK);
  
  gtk_widget_show(GK->prefs);
}

void
prefs_response_cb(GKapplet *GK, gint response, GtkDialog *dialog)
{
  g_free(GK->userid);
  g_free(GK->passwd);
  GK->userid = g_strdup(gtk_entry_get_text(GTK_ENTRY(GK->entUsr)));
  GK->passwd = g_strdup(gtk_entry_get_text(GTK_ENTRY(GK->entPwd)));
  GK->refresh_time = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(GK->spTime));
  GK->appareance = gtk_combo_box_get_active(GTK_COMBO_BOX(GK->cbApp));
  GK->max_days = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(GK->spMax));
  GK->not_time = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(GK->chkTime));
  GK->not_hours = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(GK->spHours));
  GK->not_games = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(GK->chkGames));
  
  panel_applet_gconf_set_string(GK->applet, "userid", GK->userid, NULL);
  panel_applet_gconf_set_string(GK->applet, "password", GK->passwd, NULL);
  panel_applet_gconf_set_int(GK->applet, "refresh_time", GK->refresh_time, NULL);
  panel_applet_gconf_set_int(GK->applet, "appareance", GK->appareance, NULL);
  panel_applet_gconf_set_int(GK->applet, "max_days", GK->max_days, NULL);
  panel_applet_gconf_set_bool(GK->applet, "notification_on_time", GK->not_time, NULL);
  panel_applet_gconf_set_int(GK->applet, "notification_on_time_hours", GK->not_hours, NULL);
  panel_applet_gconf_set_bool(GK->applet, "notification_on_games", GK->not_games, NULL);

  gtk_widget_destroy(GK->prefs);
  GK->prefs = NULL;

  change_appareance(GK, GK->appareance);
  change_timer(GK, GK->refresh_time);
}

void
prefs_app_cb(GtkWidget *cbApp, GKapplet *GK)
{
  int app = gtk_combo_box_get_active(GTK_COMBO_BOX(GK->cbApp));
  panel_applet_gconf_set_int(GK->applet, "appareance", app, NULL);
  change_appareance(GK, app);
}

void
about_cb(BonoboUIComponent *uic, GKapplet *GK, const gchar *verbname)
{
  static const gchar *authors [] = {
    "Stefano Maggiolo <maggiolo@mail.dm.unipi.it>",
    NULL
  };
  
  gtk_show_about_dialog (NULL,
                         "name",         _("GameKnot applet"),
                         "version",      PACKAGE_VERSION,
                         "comments",     _("Monitors a GameKnot account."),
                         "copyright",    "\xC2\xA9 2007 Stefano Maggiolo",
                         "authors",      authors,
                         "logo-icon-name",       "gameknot_applet",
                         NULL);
}

void
refresh_cb(BonoboUIComponent *uic, GKapplet *GK, const gchar *verbname)
{
  timer_cb(GK);
}

void
orient_cb(PanelApplet *applet, gint orient, GKapplet *GK)
{
  if (orient != GK->orient) change_orient(GK, orient);
}

gboolean
click_cb(GtkWidget *eventbox, GdkEventButton *event, GKapplet *GK)
{
  gchar *command;

  if (event->button != 1)
    return FALSE;
  command = g_strdup_printf("gnome-open http://gameknot.com/play_chess.pl?u=%s", GK->userid);
  g_spawn_command_line_async(command, NULL);
  g_free(command);
  return TRUE;
}

void
destroy_cb(GtkObject *object, GKapplet *GK)
{
  g_free(GK->userid);
  g_free(GK->passwd);
  if (GK->prefs != NULL) gtk_widget_destroy(GK->prefs);
#if HAVE_LIBNM_GLIB
  nm_cleanup(GK);
#endif
}
