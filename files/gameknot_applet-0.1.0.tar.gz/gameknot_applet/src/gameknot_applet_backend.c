/*
 * gameknot_applet_backend.c: information retrieve from GK.
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "gameknot_applet.h"

#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include <curl/curl.h>
#include <regex.h>

size_t write_data(const char *buffer, size_t size, size_t nmemb, char **userp)
{
  size_t len;
  len = size * nmemb;
  *userp = realloc(*userp, strlen(*userp) + len + 1);
  assert(*userp != NULL);
  strncat(*userp, buffer,len);
  return len;
}

void
gameknot_get_time(GKapplet *GK)
{
  CURL *curl = curl_easy_init();
  if (curl)
    {
      CURLcode res;
      char *url, *cookie;
      char *data = malloc(sizeof(char));
      assert(data != NULL);
      data[0] = 0;

      if (!strcmp(GK->userid, ""))
        {
          GK->hours = TIME_WRONG;
          GK->games = GAMES_UNKNOWN;
          g_free(data);
          return;
        }
      url = g_strdup_printf("http://gameknot.com/play_chess.pl?u=%s", GK->userid);
      cookie = g_strdup_printf("USERID=%s;PSW=%s", GK->userid, GK->passwd);

      curl_easy_setopt(curl, CURLOPT_URL, url);
      curl_easy_setopt(curl, CURLOPT_COOKIE, cookie);
      curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
      curl_easy_setopt(curl, CURLOPT_WRITEDATA, &data);
      res = curl_easy_perform(curl);
      curl_easy_cleanup(curl);
      if (res == 0)
        get_min_time(data, &(GK->hours), &(GK->games));
      else
        {
          GK->hours = TIME_UNKNOWN;
          GK->games = GAMES_UNKNOWN;
        }
      g_free(url);
      g_free(cookie);
      g_free(data);
    }
  else
    {
      GK->hours = TIME_UNKNOWN;
      GK->games = GAMES_UNKNOWN;
    }
}

void
get_min_time(char *data, gint *hours, gint *games)
{
  char *s;
  regex_t re, re2, move, wrong;
  char *pattern = "<TD nowrap[^>]*time control[^>]*>([^<]*)<span class=sml>([a-z]*)</span>([^<]*)<span class=sml>([a-z]*)</span></td>";
  char *pattern2 = "<TD nowrap[^>]*time control[^>]*>([^<]*)<span class=sml>([a-z]*)</span></td>";
  regmatch_t match[200];

  *hours = INT_MAX;
  *games = 0;
  regcomp(&re, pattern, REG_EXTENDED);
  regcomp(&re2, pattern2, REG_EXTENDED);
  regcomp(&move, "your move", REG_EXTENDED | REG_NOSUB);
  regcomp(&wrong, "Error logging you in", REG_EXTENDED | REG_NOSUB);
  s = strtok(data, "\n");
  while (s != NULL)
    {
      if (regexec(&wrong, s, 0, NULL, 0) == 0)
        {
          *hours = TIME_WRONG;
          *games = GAMES_UNKNOWN;
          break;
        }
      if (regexec(&move, s, 0, NULL, 0) == 0)
        {
          gint new_hours;
          *games = *games + 1;
          if (regexec(&re, s, 100, match, 0) == 0)
            {
              gint days;
              s[match[1].rm_eo] = 0;
              s[match[3].rm_eo] = 0;
              days = atoi(s + match[1].rm_so);
              new_hours = atoi(s + match[3].rm_so) + days * 24;        
            }
          else if (regexec(&re2, s, 100, match, 0) == 0)
            {
              s[match[1].rm_eo] = 0;
              s[match[2].rm_eo] = 0;
              if (!strcmp(s + match[2].rm_so, "day") || !strcmp(s + match[2].rm_so, "days"))
                new_hours = 24 * atoi(s + match[1].rm_so);
              else
                new_hours = atoi(s + match[1].rm_so);
            }
          if (new_hours < *hours)
            *hours = new_hours;
        }
      s = strtok(NULL, "\n");
    }
  regfree(&re);
  regfree(&re2);
  regfree(&move);
  regfree(&wrong);
}

