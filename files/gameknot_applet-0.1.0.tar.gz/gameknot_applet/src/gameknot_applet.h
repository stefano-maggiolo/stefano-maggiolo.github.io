/*
 * gameknot_applet.h: headers.
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __GAMEKNOT_APPLET_H__
#define __GAMEKNOT_APPLET_H__

#include "config.h"

#include <panel-applet.h>
#include <gtk/gtk.h>
#include <glib.h>
#if HAVE_LIBNM_GLIB
#include <NetworkManager/libnm_glib.h>
#endif
#include <locale.h>
#include <libintl.h>

#define TIME_UNKNOWN -1
#define TIME_WRONG -2
#define TIME_NOPLAY INT_MAX
#define GAMES_UNKNOWN -1

#define APP_GRAPHIC 0
#define APP_TEXT 1
#define APP_TEXTGRAPHIC 2

typedef struct
{
  gchar *userid; /* account's userid */
  gchar *passwd; /* account's password */
  gint refresh_time; /* refresh time (minutes) */
  guint timeout_id; /* id of the timeout */
  gint max_days; /* 100% of graphic mode */
  gint hours; /* remaining hours */
  gint games; /* games to play */
  gint prev_games; /* previously retrieved games to play */
  gint appareance; /* graphic, text or both */
  gboolean not_time; /* wheter to notify on low time */
  gint not_hours; /* notify at this remaining hour */
  gboolean not_games; /* wheter to notify on new games */
  
  PanelApplet *applet;
  PanelAppletOrient orient;
  GtkWidget *box;
  GtkWidget *label;
  GdkPixbuf *pixbufs[6];
  GtkWidget *icon;
  GtkTooltips *tooltips;

  GdkPixbuf *prefs_icon;
  GtkWidget *prefs;
  GtkWidget *entUsr;
  GtkWidget *entPwd;
  GtkWidget *spTime;
  GtkWidget *spMax;
  GtkWidget *cbApp;
  GtkWidget *chkTime;
  GtkWidget *spHours;
  GtkWidget *chkGames;

#if HAVE_LIBNM_GLIB
  libnm_glib_ctx *nm_ctx;
  guint nm_id;
#endif

#if HAVE_LIBNOTIFY
  gboolean notify; /* notify initialized properly? */
#endif
}GKapplet;

gboolean gameknot_applet_fill(PanelApplet *applet, const gchar *iid, gpointer data);
void set_image(GKapplet *GK);
void notify(GKapplet *GK);
void change_background(PanelApplet *a, PanelAppletBackgroundType type, GdkColor *color, GdkPixmap *pixmap, GKapplet *GK);
void change_appareance(GKapplet *GK, gint app);
void change_timer(GKapplet *GK, gint timer);
void change_orient(GKapplet *GK, gint orient);
void load_preferences(GKapplet *GK);

/* BACKEND */
size_t write_data(const char *buffer, size_t size, size_t nmemb, gchar **userp);
void gameknot_get_time(GKapplet *GK);
void get_min_time(gchar *data, gint *hours, gint *games);

/* CALLBACKS */
gint timer_cb(GKapplet *GK);
void preferences_cb(BonoboUIComponent *uic, GKapplet *GK, const gchar *verbname);
void about_cb(BonoboUIComponent *uic, GKapplet *GK, const gchar *verbname);
void refresh_cb(BonoboUIComponent *uic, GKapplet *GK, const gchar *verbname);
void prefs_response_cb(GKapplet *GK, gint response, GtkDialog *dialog);
void prefs_app_cb(GtkWidget *cbApp, GKapplet *GK);
void orient_cb(PanelApplet *applet, gint orient, GKapplet *GK);
gboolean click_cb(GtkWidget *eventbox, GdkEventButton *event, GKapplet *GK);
void destroy_cb(GtkObject *object, GKapplet *GK);

/* UTILITY */
void format_time_string(gchar **s, gint h);
void widget_reparent(GtkWidget *w, GtkContainer *old, GtkContainer *new);

/* NM */
#if HAVE_LIBNM_GLIB
void nm_init(GKapplet *GK);
void nm_update(libnm_glib_ctx *ctx, GKapplet *GK);
void nm_cleanup(GKapplet *GK);
#endif

#endif
