/*
 * gameknot_applet_nm.c: NetworkManager integration.
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "gameknot_applet.h"

#if HAVE_LIBNM_GLIB
#include <NetworkManager/libnm_glib.h>

void
nm_init(GKapplet *GK)
{
  if (GK->nm_ctx == NULL) GK->nm_ctx = libnm_glib_init();
  if (GK->nm_ctx != NULL) GK->nm_id = libnm_glib_register_callback(GK->nm_ctx, (libnm_glib_callback_func)nm_update, (gpointer)GK, NULL);
}

void
nm_update(libnm_glib_ctx *ctx, GKapplet *GK)
{
  timer_cb(GK);
}

void
nm_cleanup(GKapplet *GK)
{
  if (GK->nm_id != 0 && GK->nm_ctx != NULL) {
    libnm_glib_unregister_callback(GK->nm_ctx, GK->nm_id);
    libnm_glib_shutdown(GK->nm_ctx);
    GK->nm_ctx = NULL;
    GK->nm_id = 0;
  }
}
#endif
