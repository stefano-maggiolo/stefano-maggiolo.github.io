/*
 * gameknot_applet.c: main.
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "gameknot_applet.h"

#include <assert.h>
#include <string.h>
#include <limits.h>

#include <gconf/gconf-client.h>
#include <panel-applet-gconf.h>
#if HAVE_LIBNOTIFY
#include <libnotify/notify.h>
#endif

static const BonoboUIVerb menu_verbs [] = {
  BONOBO_UI_UNSAFE_VERB ("Preferences", preferences_cb),
  BONOBO_UI_UNSAFE_VERB ("Refresh", refresh_cb), 
  BONOBO_UI_UNSAFE_VERB ("About", about_cb), 
  BONOBO_UI_VERB_END
};

static const gchar *const icons[] = {
  PIXMAPS_DIR"/gameknot_applet_time_25.png",
  PIXMAPS_DIR"/gameknot_applet_time_50.png",
  PIXMAPS_DIR"/gameknot_applet_time_75.png",
  PIXMAPS_DIR"/gameknot_applet_time_100.png",
  PIXMAPS_DIR"/gameknot_applet_time_noplay.png",
  PIXMAPS_DIR"/gameknot_applet_time_unknown.png",
  NULL
};

#if HAVE_LIBNOTIFY
void
notify(GKapplet *GK)
{
  NotifyNotification *n;
  g_return_if_fail(GK->notify);
  if (GK->not_games == TRUE && GK->games > GK->prev_games && GK->games > 0 && GK->prev_games >= 0)
    {
      n = notify_notification_new(_("GameKnot applet"), _("It's your turn in a game."), DATADIR"/icons/hicolor/scalable/apps/gameknot_applet.svg", NULL);
      notify_notification_attach_to_widget(n, GK->icon);
      notify_notification_show(n, NULL);
    }
  if (GK->not_time == TRUE && GK->hours > 0 && GK->hours <= GK->not_hours)
    {
      n = notify_notification_new(_("GameKnot applet"), _("You are low on time on a game."), DATADIR"/icons/hicolor/scalable/apps/gameknot_applet.svg", NULL);
      notify_notification_attach_to_widget(n, GK->icon);
      notify_notification_show(n, NULL);
    }
  return;
}
#endif

void
set_image(GKapplet *GK)
{
  gint image;
  if (GK->hours == TIME_UNKNOWN || GK->hours == TIME_WRONG)
    image = 5;
  else if (GK->hours == TIME_NOPLAY)
    image = 4;
  else
    {
      gint perc = GK->hours * 100.0 / (GK->max_days * 24);
      if (perc <= 30) image = 0;
      else if (perc <= 70) image = 1;
      else if (perc <= 90) image = 2;
      else image = 3;
    }

  if (GK->pixbufs[image] == NULL)
    GK->pixbufs[image] = gdk_pixbuf_new_from_file_at_size(icons[image], 24, 24, NULL);
  
  gtk_image_set_from_pixbuf(GTK_IMAGE(GK->icon), GK->pixbufs[image]);
}

void
change_timer(GKapplet *GK, gint timer)
{
  g_source_remove(GK->timeout_id);
  GK->timeout_id = g_timeout_add(60000*timer, (GtkFunction) timer_cb, GK);
  GK->refresh_time = timer;
  timer_cb(GK);
}

void
change_appareance(GKapplet *GK, gint app)
{
  gtk_widget_show_all(GTK_WIDGET(GK->applet));
  GK->appareance = app;
  if (app == APP_GRAPHIC) gtk_widget_hide(GK->label);
  if (app == APP_TEXT) gtk_widget_hide(GK->icon);
}

void
change_background (PanelApplet                 *a,
                    PanelAppletBackgroundType   type,
                    GdkColor                    *color,
                    GdkPixmap                   *pixmap,
                    GKapplet                  *GK) 
{
  GtkRcStyle *rc_style;
  GtkStyle *style;
  
  gtk_widget_set_style(GTK_WIDGET(GK->applet), NULL);
  rc_style = gtk_rc_style_new();
  gtk_widget_modify_style(GTK_WIDGET(GK->applet), rc_style);
  gtk_rc_style_unref(rc_style);
  
  switch (type)
    {
    case PANEL_COLOR_BACKGROUND:
      gtk_widget_modify_bg(GTK_WIDGET(GK->applet), GTK_STATE_NORMAL, color);
      break;
      
    case PANEL_PIXMAP_BACKGROUND:
      style = gtk_style_copy(GTK_WIDGET(GK->applet)->style);
      if (style->bg_pixmap[GTK_STATE_NORMAL])
        g_object_unref(style->bg_pixmap[GTK_STATE_NORMAL]);
      style->bg_pixmap[GTK_STATE_NORMAL] = g_object_ref(pixmap);
      gtk_widget_set_style(GTK_WIDGET(GK->applet), style);
      g_object_unref(style);
      break;
      
    case PANEL_NO_BACKGROUND:
    default:
      break;
    }
}  

void
load_preferences(GKapplet *GK)
{
  GK->userid = panel_applet_gconf_get_string(GK->applet, "userid", NULL);
  GK->passwd = panel_applet_gconf_get_string(GK->applet, "password", NULL);
  GK->refresh_time = panel_applet_gconf_get_int(GK->applet, "refresh_time", NULL);
  GK->appareance = panel_applet_gconf_get_int(GK->applet, "appareance", NULL);
  GK->max_days = panel_applet_gconf_get_int(GK->applet, "max_days", NULL);
  GK->not_time = panel_applet_gconf_get_bool(GK->applet, "notification_on_time", NULL);
  GK->not_hours = panel_applet_gconf_get_int(GK->applet, "notification_on_time_hours", NULL);
  GK->not_games = panel_applet_gconf_get_bool(GK->applet, "notification_on_games", NULL);
  if (GK->userid == NULL) GK->userid = g_strdup("");
  if (GK->passwd == NULL) GK->passwd = g_strdup("");
  if (GK->refresh_time < 1) GK->refresh_time = 20;
  if (GK->max_days < 1) GK->max_days = 3;
  if (GK->not_hours < 1) GK->not_hours = 12;
#if !HAVE_LIBNOTIFY
  GK->not_time = GK->not_games = FALSE;
#endif
}

void
change_orient(GKapplet *GK, gint orient)
{
  GtkWidget *tmp;
  if (orient == PANEL_APPLET_ORIENT_LEFT || orient == PANEL_APPLET_ORIENT_RIGHT)
    {
      gtk_label_set_justify(GTK_LABEL(GK->label), GTK_JUSTIFY_CENTER);
      tmp = gtk_vbox_new(FALSE, 0);
    }
  else
    {
      gtk_label_set_justify(GTK_LABEL(GK->label), GTK_JUSTIFY_LEFT);
      tmp = gtk_hbox_new(FALSE, 0);
    }
  
  widget_reparent(GK->icon, GTK_CONTAINER(GK->box), GTK_CONTAINER(tmp));
  widget_reparent(GK->label, GTK_CONTAINER(GK->box), GTK_CONTAINER(tmp));
  
  if (GK->box != NULL) gtk_widget_destroy(GK->box);
  GK->box = tmp;
  gtk_container_add(GTK_CONTAINER(GK->applet), GK->box);
  GK->orient = orient;
  change_appareance(GK, GK->appareance);
}

gboolean
gameknot_applet_fill (PanelApplet *applet,
   const gchar *iid,
   gpointer data)
{
  GKapplet *GK = g_new0(GKapplet, 1);
  
  printf("Let's roll!\n");
  
  if (strcmp(iid, "OAFIID:gameknot_applet") != 0)
    return FALSE;

  setlocale(LC_ALL, "");
  bindtextdomain("gameknot_applet", DATADIR"/locale/");
  textdomain("gameknot_applet");

  GK->applet = applet;
  load_preferences(GK);
  gtk_window_set_default_icon_from_file(DATADIR"/icons/hicolor/scalable/apps/gameknot_applet.svg", NULL);

  GK->orient = panel_applet_get_orient(applet);
  
  GK->label = gtk_label_new("");
  GK->icon = gtk_image_new();
  GK->box = NULL;
  change_orient(GK, GK->orient);

  GK->prefs = NULL;
  GK->tooltips = gtk_tooltips_new();
  GK->timeout_id = g_timeout_add(60000*GK->refresh_time, (GtkFunction) timer_cb, (gpointer)GK);
  panel_applet_setup_menu_from_file (applet, DATADIR, "gameknot_applet.xml", NULL, menu_verbs, (gpointer)GK);
  g_signal_connect(applet, "change_background", G_CALLBACK(change_background), (gpointer)GK);
  g_signal_connect(applet, "change_orient", G_CALLBACK(orient_cb), (gpointer)GK);
  g_signal_connect(applet, "button_press_event", G_CALLBACK(click_cb), (gpointer)GK);
  g_signal_connect(applet, "destroy", G_CALLBACK(destroy_cb), (gpointer)GK);

#if HAVE_LIBNM_GLIB
  nm_init(GK);
#endif
  
#if HAVE_LIBNOTIFY
  GK->notify = notify_init("gameknot_applet")? TRUE: FALSE;
#endif
  
  if (panel_applet_get_locked_down (applet))
    {
      BonoboUIComponent *popup_component;
      popup_component = panel_applet_get_popup_component(applet);
      bonobo_ui_component_set_prop(popup_component, "/commands/Props", "hidden", "1", NULL);
    }

  change_appareance(GK, GK->appareance);
  timer_cb(GK);
  
  return TRUE;
}

PANEL_APPLET_BONOBO_FACTORY ("OAFIID:gameknot_applet_Factory",
                             PANEL_TYPE_APPLET,
                             _("GameKnot applet"),
                             "0",
                             gameknot_applet_fill,
                             NULL);
