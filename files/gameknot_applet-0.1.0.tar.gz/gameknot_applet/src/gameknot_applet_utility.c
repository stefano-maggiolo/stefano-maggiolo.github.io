/*
 * gameknot_applet_utility.c: general utility routine.
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "gameknot_applet.h"

void
widget_reparent(GtkWidget *w, GtkContainer *old, GtkContainer *new)
{
  gtk_widget_ref(w);
  if (old != NULL) gtk_container_remove(old, w);
  gtk_container_add(new, w);
  gtk_widget_unref(w);
}

void
format_time_string(gchar **s, gint h)
{
  gchar *t = NULL;
  
  if (h >= 48)
    t = g_strdup_printf(_("%d days"), h / 24);
  else if (h >= 24)
    t = g_strdup(_("1 day"));
  
  if (h % 24 == 1)
    *s = (t == NULL)? g_strdup(_("1 hour remaining")): g_strdup_printf(_("%s and 1 hour remaining"), t);
  else if (h % 24 != 0)
    *s = (t == NULL)? g_strdup_printf(_("%d hours remaining"), h % 24): g_strdup_printf(_("%s and %d hours remaining"), t, h % 24);
  else
    *s = (t == NULL)? g_strdup(_("0 hours remaining")): g_strdup_printf(_("%s remaining"), t);
  g_free(t);
}
