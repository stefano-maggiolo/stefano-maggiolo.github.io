/*
 * netviz.h
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __NETVIZ_H__
#define __NETVIZ_H__

#include <gtk/gtk.h>

/*#define MEMDEBUG*/
/*#define DEBUG*/

#define MAX_ITERAZIONI 1000
#define EPS 0.00000000001
#define BIG 100000000000.0
#define EIGEN 4 /*numero di autovalori*/

#define HK1 0
#define HK2 1
#define TORG 2

#define HK1_PIVOT 64

typedef struct
{
  double red, green, blue;
} Color;

typedef struct
{
  double X, Y;
} Point;

typedef struct
{
  double
  w, h;
  GtkWidget *window, *btEsci, *btNuovo, *btCentra;
  GtkWidget *daMain; /*drawing area*/
  GtkWidget *daFirst, *daSecond; /*drawing area*/
  GtkWidget *cbFirst1, *cbFirst2;
  GtkWidget *cbSecond1, *cbSecond2;
  GtkWidget *rbHK1, *rbHK2, *rbT;
  GtkWidget *lbInfo;

  GtkWidget *nuovo, *btOK, *txtGrafo;
  GtkTextBuffer *bufGrafo;
  GtkWidget *btLenzuolo, *btLenzuoloApp, *btCilindro, *btMoebius,
    *btToro, *btKlein,
    *btBipartito, *btCricca,
    *btLineare, *btCiclico, *btCasuale, *btIpercubo;
  GtkWidget *spL1, *spL2, *spLA1, *spLA2, *spC1, *spC2, *spM1, *spM2,
    *spT1, *spT2, *spK1, *spK2,
    *spB, *spC, *spL, *spT, *spR, *spRP, *spI;
  
  int daFirstActive, daSecondActive;
  Point daFirstPoint, daSecondPoint;

  Point daMainNW;
  Point daMainSE;
  
  Point daQuadrante1;
  Point daQuadranteC;

  Point scaleP;
  int scaling;
#ifdef MEMDEBUG
  long long allocati;
#endif
} Windowinfo;

typedef struct
{
  int n, n2; /* vertici */
  int m, m2; /* dimensione grande */
  int **e; /* Nx? = E */
  int *d; /* N */
  double **M; /* MxN */
  double **eigen; /* EIGENxM */
  int *scelti; /* N */
  int *listaScelti; /*  M */
  int **distanze; /* /NxN */
  double *sommaDistanze; /* N */
  Point *P; /* N */
  double eigenScelti[2][EIGEN];
  int timeBFS, timeBegin;
  int eigenWarning[EIGEN]; /* se gli autovettori non sono ben determinati */
} Model;

void model_init(void);
void liberamodel(void);
void esegui(int how);
void leggi(char *buffer, int how);

void *myalloc(size_t byte);
time_t stampaTempo(char *s);
double randouble(double a, double b);
double sqr(double a);
double cube(double a);
double ndist(double *p, int n);
void ndiff(double *a, double *b, double *c, int n);
void nsomma(double *a, double *b, double *c, int n);
void nprod_s(double *a, double b, double *c, int n);
double nprod_scal(double *a, double *b, int n);
void nvers(double *a, double *b, int n);
void ncopy(double *a, double *b, int n);

cairo_t *begin_paint(GdkDrawable *window);
void end_paint(cairo_t *cr);

void on_eigen_changed(GtkWidget *widget, gpointer data);
void create_window(void);

void drawQuadrante(GtkWidget *da, int active, Point P);
void drawPoint(GtkWidget *widget, int i);
void drawMain(GtkWidget *widget, int adatta);


#endif
