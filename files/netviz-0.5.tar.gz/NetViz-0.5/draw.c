/*
 * draw.c
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <cairo.h>
#include <cairo-xlib.h>
#include <math.h>
#include <stdlib.h>
#include "NetViz.h"

extern Windowinfo win;
extern Model model;
extern Color red;
extern Color blue;
extern Color black;
extern Color white;

Point
Posizione(int c)
{
  Point P;
  int k, h;
  double *v = malloc(sizeof(double) * model.m);
  double *e1 = malloc(sizeof(double) * model.m);
  double *e2 = malloc(sizeof(double) * model.m);
  for (k = 0; k < model.m; k++)
    {
      v[k] = model.M[k][c];
      e1[k] = 0;
      e2[k] = 0;
      for (h = 0; h < EIGEN; h++)
        {
          e1[k] += model.eigenScelti[0][h] * model.eigen[h][k];
          e2[k] += model.eigenScelti[1][h] * model.eigen[h][k];
        }
    }
  P.X = nprod_scal(v, e1, model.m);
  P.Y = nprod_scal(v, e2, model.m);
  free(v);
  free(e1);
  free(e2);
  return P;
}

void
drawQuadrante(GtkWidget *da, int active, Point P)
{
  cairo_t *cr;
  
  cr = begin_paint(da->window);

  cairo_set_source_rgba(cr, white.red, white.green, white.blue, 1);
  cairo_new_path(cr);
  cairo_move_to(cr, 0, 0);
  cairo_line_to(cr, 150, 0);
  cairo_line_to(cr, 150, 150);
  cairo_line_to(cr, 0, 150);
  cairo_line_to(cr, 0, 0);
  cairo_fill(cr);
  
  cairo_set_source_rgba(cr, black.red, black.green, black.blue, active? 1: 0.2);
  cairo_new_path(cr);
  cairo_arc(cr, win.daQuadranteC.X, win.daQuadranteC.Y, win.daQuadrante1.X, 0, 2 * M_PI);
  cairo_stroke(cr);
  
  cairo_set_source_rgba(cr, black.red, black.green, black.blue, active? 1: 0.2);
  cairo_new_path(cr);
  cairo_arc(cr, win.daQuadranteC.X, win.daQuadranteC.Y, 2, 0, 2 * M_PI);
  cairo_fill(cr);

  cairo_set_source_rgba(cr, red.red, red.green, red.blue, active? 1: 0.2);
  cairo_new_path(cr);
  cairo_arc(cr,
            win.daQuadranteC.X + win.daQuadrante1.X * P.X,
            win.daQuadranteC.Y + win.daQuadrante1.Y * P.Y,
            4, 0, 2 * M_PI);
  cairo_fill (cr);
  end_paint (cr);
}

void
drawEdge(GtkWidget *widget, int i)
{
  int j;
  cairo_t *cr;
  Point C, U;
  U.X = win.w / (win.daMainSE.X - win.daMainNW.X);
  U.Y = win.h / (win.daMainSE.Y - win.daMainNW.Y);
  C.X = - win.daMainNW.X * U.X;
  C.Y = -win.daMainNW.Y * U.Y;

  for (j = 0; j < model.d[i]; j++)
    if (model.e[i][j] < i)
      {
        cr = begin_paint(widget->window);

        cairo_set_source_rgba(cr, black.red, black.green, black.blue, 0.2);
        cairo_set_line_width (cr, 2.0);

        cairo_new_path(cr);
        cairo_move_to(cr, C.X + U.X * model.P[i].X, C.Y + U.Y * model.P[i].Y);
        cairo_line_to(cr, C.X + U.X * model.P[model.e[i][j]].X, C.Y + U.Y * model.P[model.e[i][j]].Y);
        cairo_stroke(cr);
  
        end_paint (cr);  
      }

}
void
drawPoint(GtkWidget *widget, int i)
{
  cairo_t *cr;
  Point C, U;
  U.X = win.w / (win.daMainSE.X - win.daMainNW.X);
  U.Y = win.h / (win.daMainSE.Y - win.daMainNW.Y);
  C.X = - win.daMainNW.X * U.X;
  C.Y = - win.daMainNW.Y * U.Y;
  
  cr = begin_paint(widget->window);

  if (model.scelti[i])
    cairo_set_source_rgba(cr, red.red, red.green, red.blue, 0.5);
  else
    cairo_set_source_rgba(cr, blue.red, blue.green, blue.blue, 0.5);
  cairo_new_path(cr);
  cairo_arc(cr, C.X + U.X * model.P[i].X, C.Y + U.Y * model.P[i].Y, 2, 0, 2 * M_PI);
  cairo_fill (cr);

  end_paint (cr);
}

void
drawMain(GtkWidget *widget, int adatta)
{
  int i;
  cairo_t *cr;
  double maxX = 0, maxY = 0, minX = 0, minY = 0;

  stampaTempo("Sto calcolando le posizioni in dimensione bassa...");
  for (i = 0; i < model.n; i++)
    {
      model.P[i] = Posizione(i);
      if (maxX < model.P[i].X) maxX = model.P[i].X;
      if (maxY < model.P[i].Y) maxY = model.P[i].Y;
      if (minX > model.P[i].X) minX = model.P[i].X;
      if (minY > model.P[i].Y) minY = model.P[i].Y;
    }
  if (adatta)
    {
      if (maxX == 0) maxX = 0.1;
      if (maxY == 0) maxY = 0.1;
      if (minX == 0) minX = -0.1;
      if (minY == 0) minY = -0.1;
      win.daMainNW.X = minX * 1.1;
      win.daMainNW.Y = minY * 1.1;
      win.daMainSE.X = maxX * 1.1;
      win.daMainSE.Y = maxY * 1.1;
    }
  stampaTempo("Fatto");

  stampaTempo("Sto disegnando...");
  cr = begin_paint(widget->window);
  cairo_set_source_rgba(cr, white.red, white.green, white.blue, 1);
  cairo_new_path(cr);
  cairo_move_to(cr, 0, 0);
  cairo_line_to(cr, 600, 0);
  cairo_line_to(cr, 600, 600);
  cairo_line_to(cr, 0, 600);
  cairo_line_to(cr, 0, 0);
  cairo_fill(cr);
  end_paint(cr);
  
  for (i = 0; i < model.n; i++)
    drawEdge(widget, i);
  for (i = 0; i < model.n; i++)
    drawPoint(widget, i);
  stampaTempo("Fatto");
}
