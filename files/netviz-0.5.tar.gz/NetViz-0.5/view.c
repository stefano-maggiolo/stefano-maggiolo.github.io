/*
 * view.c
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <gtk/gtk.h>
#include <cairo.h>
#include <cairo-xlib.h>
#include <gdk/gdkx.h>
#include <glade/glade.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "NetViz.h"

Windowinfo win;
Model model;
Color red = {1, 0, 0};
Color green = {0, 1, 0};
Color blue = {0, 0, 1};
Color yellow = {0, 1, 1};
Color black = {0, 0, 0};
Color white = {1, 1, 1};

/*****************************************************
 * Cairo
 *****************************************************/

cairo_t *
begin_paint(GdkDrawable *window)
{
  Display *dpy;
  Drawable xid;
  Visual *visual;
  GdkDrawable *drawable;
  gint x_offset, y_offset;
  gint width, height;
  cairo_surface_t *surface;
  cairo_t *cr;
  
  if (GDK_IS_WINDOW (window))
	gdk_window_get_internal_paint_info (window, &drawable, &x_offset, &y_offset);
  else
	drawable = window;
  
  dpy = gdk_x11_drawable_get_xdisplay(drawable);
  xid = gdk_x11_drawable_get_xid(drawable);
  gdk_drawable_get_size(drawable, &width, &height);
  visual = GDK_VISUAL_XVISUAL(gdk_drawable_get_visual (drawable));
  surface = cairo_xlib_surface_create (dpy, xid, visual,
                                       width, height);
  cr = cairo_create (surface);
  cairo_surface_destroy (surface);
  
  if (GDK_IS_WINDOW (window))
	cairo_translate (cr, -x_offset, -y_offset);
  
  return cr;
}

void
end_paint(cairo_t *cr)
{
  cairo_destroy (cr);
}

/*****************************************************
 * GTK (principale)
 *****************************************************/

gboolean
on_daMain_motion_notify_event(GtkWidget *widget, GdkEventMotion *event, gpointer data)
{
  Point P;
  GdkModifierType state;
  static Point Pold;
  Point newNW, newSE;
  int x, y;

  gdk_window_get_pointer(event->window, &x, &y, &state);
  P.X = x; P.Y = y;
  if ((P.X - Pold.X != 0 || P.Y - Pold.Y != 0) && state & GDK_BUTTON1_MASK && (state & GDK_SHIFT_MASK)) /* translate */
    {
      newNW.X = win.daMainNW.X + (P.X - Pold.X) * (win.daMainNW.X - win.daMainSE.X) / win.w;
      newNW.Y = win.daMainNW.Y + (P.Y - Pold.Y) * (win.daMainNW.Y - win.daMainSE.Y) / win.h;
      newSE.X = win.daMainSE.X + (P.X - Pold.X) * (win.daMainNW.X - win.daMainSE.X) / win.w;
      newSE.Y = win.daMainSE.Y + (P.Y - Pold.Y) * (win.daMainNW.Y - win.daMainSE.Y) / win.h;
      win.daMainNW = newNW;
      win.daMainSE = newSE;
      drawMain(widget, 0);
    }
  Pold = P;
  return TRUE;
}

gboolean
on_daMain_button_press_event (GtkWidget        *widget,
                          GdkEventButton *event,
                          gpointer        data)
{
  GdkModifierType state;
  Point P;
  Point newNW, newSE;
  int x, y;
  double w = (win.daMainSE.X - win.daMainNW.X);
  double h = (win.daMainSE.Y - win.daMainNW.Y);

  gdk_window_get_pointer(event->window, &x, &y, &state);
  P.X = x;
  P.Y = y;
  if (state & GDK_BUTTON1_MASK && ! (state & (GDK_SHIFT_MASK | GDK_CONTROL_MASK)))
    {
      newNW.X = win.daMainNW.X + w * (P.X - win.w/2) / win.w;
      newNW.Y = win.daMainNW.Y + h * (P.Y - win.h/2) / win.h;
      newSE.X = win.daMainSE.X + w * (P.X - win.w/2) / win.w;
      newSE.Y = win.daMainSE.Y + h * (P.Y - win.h/2) / win.h;
      newNW.X += w / 4;
      newNW.Y += h / 4;
      newSE.X += - w / 4;
      newSE.Y += - h / 4;
      win.daMainNW = newNW;
      win.daMainSE = newSE;
    }
  else if (state & GDK_BUTTON3_MASK && ! (state & (GDK_SHIFT_MASK | GDK_CONTROL_MASK)))
    {
      newNW.X = win.daMainNW.X + w * (P.X - win.w/2) / win.w;
      newNW.Y = win.daMainNW.Y + h * (P.Y - win.h/2) / win.h;
      newSE.X = win.daMainSE.X + w * (P.X - win.w/2) / win.w;
      newSE.Y = win.daMainSE.Y + h * (P.Y - win.h/2) / win.h;
      newNW.X += - w / 2;
      newNW.Y += - h / 2;
      newSE.X += w / 2;
      newSE.Y += h / 2;
      win.daMainNW = newNW;
      win.daMainSE = newSE;
    }
  win.scaling = 0;
  drawMain(widget, 0);
  return TRUE;
}

gboolean
on_daFirst_button_press_event (GtkWidget	   *widget,
                               GdkEventButton *event,
                               gpointer	    data)
{
  int x, y;
  double X, Y;
  GdkModifierType state;
  if (win.daFirstActive == 1)
    {
      gdk_window_get_pointer(event->window, &x, &y, &state);
      if (state & GDK_BUTTON1_MASK)
        {
          double v;
          X = (double)(x - win.daQuadranteC.X) / win.daQuadrante1.X;
          Y = (double)(y - win.daQuadranteC.Y) / win.daQuadrante1.Y;
          v = sqrt(X*X + Y*Y);
          X /= v;
          Y /= v;
          win.daFirstPoint.X = X;
          win.daFirstPoint.Y = Y;
        }
      drawQuadrante(win.daFirst, win.daFirstActive, win.daFirstPoint);
      on_eigen_changed(win.daFirst, NULL);
    }
  return TRUE;
}

gboolean
on_daSecond_button_press_event (GtkWidget	     *widget,
                                GdkEventButton *event,
                                gpointer	      data)
{
  int x, y;
  double X, Y;
  GdkModifierType state;
  if (win.daSecondActive == 1)
    {
      gdk_window_get_pointer(event->window, &x, &y, &state);
      if (state & GDK_BUTTON1_MASK)
        {
          double v;
          X = (double)(x - win.daQuadranteC.X) / win.daQuadrante1.X;
          Y = (double)(y - win.daQuadranteC.Y) / win.daQuadrante1.Y;
          v = sqrt(X*X + Y*Y);
          X /= v;
          Y /= v;
          win.daSecondPoint.X = X;
          win.daSecondPoint.Y = Y;
        } 
      drawQuadrante(win.daSecond, win.daSecondActive, win.daSecondPoint);
      on_eigen_changed(win.daSecond, NULL);
    }
  return TRUE;
}

gboolean
on_daMain_expose_event(GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  drawMain(widget, 0);
  return TRUE;
}

gboolean
on_daFirst_expose_event(GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  drawQuadrante(widget, win.daFirstActive, win.daFirstPoint);
  return TRUE;
}

gboolean
on_daSecond_expose_event(GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  drawQuadrante(widget, win.daSecondActive, win.daSecondPoint);
  return TRUE;
}

void
on_eigen_changed(GtkWidget *widget, gpointer data)
{
  int F1, F2, S1, S2, i;
  F1 = gtk_combo_box_get_active(GTK_COMBO_BOX(win.cbFirst1));
  F2 = gtk_combo_box_get_active(GTK_COMBO_BOX(win.cbFirst2));
  S1 = gtk_combo_box_get_active(GTK_COMBO_BOX(win.cbSecond1));
  S2 = gtk_combo_box_get_active(GTK_COMBO_BOX(win.cbSecond2));
  if (F1 < 0 || F2 < 0 || S1 < 0 || S2 < 0) return; /* non ancora inizializzato */
  for (i = 0; i < EIGEN; i++)
    model.eigenScelti[0][i] = model.eigenScelti[1][i] = 0;


  if (F2 == 0)
    {
      win.daFirstActive = 0;
      model.eigenScelti[0][F1] = 1;
    }
  else
    {
      win.daFirstActive = 1;
      if (F1 != F2-1)
        {
          model.eigenScelti[0][F1] = win.daFirstPoint.X;
          model.eigenScelti[0][F2-1] = win.daFirstPoint.Y;
        }
      else model.eigenScelti[0][F1] = 1;
    }
  if (S2 == 0)
    {
      win.daSecondActive = 0;
      model.eigenScelti[1][S1] = 1;
    }
  else
    {
      win.daSecondActive = 1;
      if (S1 != S2-1)
        {
          model.eigenScelti[1][S1] = win.daSecondPoint.X;
          model.eigenScelti[1][S2-1] = win.daSecondPoint.Y;
        }
      else model.eigenScelti[1][S1] = 1;
    }
  if (widget != NULL)
    {
      /* siamo chiamati da leggi() */
      drawQuadrante(win.daFirst, win.daFirstActive, win.daFirstPoint);
      drawQuadrante(win.daSecond, win.daSecondActive, win.daSecondPoint);
      drawMain(win.daMain, 1);
    }
}

int
how(void)
{
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(win.rbHK1)))
    return HK1;
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(win.rbHK2)))
    return HK2;
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(win.rbT)))
    return TORG;
  else
    return HK1;
}

void
on_group_changed(GtkWidget *widget, gpointer user_data)
{
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
    {
      liberamodel();
      esegui(how());
      drawMain(win.daMain, 1);
    }
}

void
on_btNuovo_clicked(GtkWidget *widget, gpointer user_data)
{
  gtk_widget_show(win.nuovo);
}

void
on_btCentra_clicked(GtkWidget *widget, gpointer user_data)
{
  drawMain(win.daMain, 1);
}

/*****************************************************
 * GTK (principale)
 *****************************************************/

void
on_btOK_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gchar *buffer;
  gtk_widget_hide(win.nuovo);

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  buffer = gtk_text_buffer_get_text(win.bufGrafo, &s, &e, TRUE);

  liberamodel();
  leggi(buffer, how());
  drawMain(win.daMain, 1);
}

void
ins(int n)
{
  gchar s[50];
  sprintf(s, "%d ", n);
  gtk_text_buffer_insert_at_cursor(win.bufGrafo, s, strlen(s));
}

void
insLN(int n)
{
  gchar s[50];
  sprintf(s, "%d\n", n);
  gtk_text_buffer_insert_at_cursor(win.bufGrafo, s, strlen(s));
}


void
on_btLenzuolo_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, M, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spL1));
  M = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spL2));
  
  insLN(N*M);
  
  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
        if (i == 0 && j == 0) { ins(2); ins(1); insLN(M); }
        else if (i == 0 && j == M-1) { ins(2); ins(M-2); insLN(2*M-1); }
        else if (i == N-1 && j == 0) { ins(2); ins(M*(N-2)); insLN(M*(N-1)+1); }
        else if (i == N-1 && j == M-1) { ins(2); ins(M*(N-1)-1); insLN(N*M-2); }
        else if (i == 0) { ins(3); ins(j-1); ins(j+1); insLN(M+j); }
        else if (j == 0) { ins(3); ins((i-1)*M); ins(i*M+1); insLN((i+1)*M); }
        else if (i == N-1) { ins(3); ins((N-2)*M+j); ins((N-1)*M+j-1); insLN((N-1)*M+j+1); }
        else if (j == M-1) { ins(3); ins(i*M-1); ins((i+1)*M-2); insLN((i+2)*M-1); }
        else {ins(4); ins((i-1)*M+j); ins(i*M+j-1); ins(i*M+j+1); insLN((i+1)*M+j); }
      }
}

void
on_btLenzuoloApp_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, M, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spLA1));
  M = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spLA2));

  insLN(N*M + 1);

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
        if (i == 0 && j == 0) { ins(3); ins(1); ins(M); insLN(N*M); }
        else if (i == 0 && j == M-1) { ins(3); ins(M-2); ins(2*M-1); insLN(N*M); }
        else if (i == N-1 && j == 0) { ins(3); ins(M*(N-2)); ins(M*(N-1)+1); insLN(N*M); }
        else if (i == N-1 && j == M-1) { ins(3); ins(M*(N-1)-1); ins(N*M-2); insLN(N*M); }
        else if (i == 0) { ins(3); ins(j-1); ins(j+1); insLN(M+j); }
        else if (j == 0) { ins(3); ins((i-1)*M); ins(i*M+1); insLN((i+1)*M); }
        else if (i == N-1) { ins(3); ins((N-2)*M+j); ins((N-1)*M+j-1); insLN((N-1)*M+j+1); }
        else if (j == M-1) { ins(3); ins(i*M-1); ins((i+1)*M-2); insLN((i+2)*M-1); }
        else {ins(4); ins((i-1)*M+j); ins(i*M+j-1); ins(i*M+j+1); insLN((i+1)*M+j); }
      }

  ins(4); ins(0); ins(M-1); ins((N-1)*M); insLN(N*M-1);
}

void
on_btCilindro_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, M, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spC1));
  M = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spC2));

  insLN(N*M);

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
        if (i == 0 && j == 0) { ins(3); ins(1); ins(M-1); insLN(M); }
        else if (i == 0 && j == M-1) { ins(3); ins(0); ins(M-2); insLN(2*M-1); }
        else if (i == N-1 && j == 0) { ins(3); ins(M*(N-2)); ins(M*(N-1)+1); insLN(N*M-1); }
        else if (i == N-1 && j == M-1) { ins(3); ins(M*(N-1)-1); ins(M*(N-1)); insLN(N*M-2); }
        else if (i == 0) { ins(3); ins(j-1); ins(j+1); insLN(M+j); }
        else if (j == 0) { ins(4); ins((i-1)*M); ins(i*M+1); ins((i+1)*M-1); insLN((i+1)*M); }
        else if (i == N-1) { ins(3); ins((N-2)*M+j); ins((N-1)*M+j-1); insLN((N-1)*M+j+1); }
        else if (j == M-1) { ins(4); ins(i*M-1); ins(i*M); ins((i+1)*M-2); insLN((i+2)*M-1); }
        else {ins(4); ins((i-1)*M+j); ins(i*M+j-1); ins(i*M+j+1); insLN((i+1)*M+j); }
      }
}

void
on_btMoebius_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, M, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spM1));
  M = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spM2));

  insLN(N*M);

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
        if (i == 0 && j == 0) { ins(3); ins(1); ins(M); insLN(N*M-1); }
        else if (i == 0 && j == M-1) { ins(3); ins(M-2); ins(2*M-1); insLN((N-1)*M); }
        else if (i == N-1 && j == 0) { ins(3); ins(M-1); ins(M*(N-2)); insLN(M*(N-1)+1); }
        else if (i == N-1 && j == M-1) { ins(3); ins(0); ins(M*(N-1)-1); insLN(N*M-2); }
        else if (i == 0) { ins(3); ins(j-1); ins(j+1); insLN(M+j); }
        else if (j == 0) { ins(4); ins((i-1)*M); ins(i*M+1); ins((N-i)*M-1); insLN((i+1)*M); }
        else if (i == N-1) { ins(3); ins((N-2)*M+j); ins((N-1)*M+j-1); insLN((N-1)*M+j+1); }
        else if (j == M-1) { ins(4); ins(i*M-1); ins((N-i-1)*M); ins((i+1)*M-2); insLN((i+2)*M-1); }
        else {ins(4); ins((i-1)*M+j); ins(i*M+j-1); ins(i*M+j+1); insLN((i+1)*M+j); }
      }
}

void
on_btToro_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, M, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spT1));
  M = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spT2));

  insLN(N*M);

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
        ins(4);
        ins(i*M+((M+j-1)%M));
        ins(i*M+((M+j+1)%M));
        ins(((N+i-1)%N)*M+j);
        insLN(((N+i+1)%N)*M+j);
      }
}

void
on_btKlein_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, M, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spK1));
  M = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spK2));

  insLN(N*M);

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
        if (i == 0 && j == 0) { ins(3); ins(1); ins(M); insLN((N-1)*M); }
        else if (i == 0 && j == M-1) { ins(3); ins(M-2); ins(2*M-1); insLN(N*M-1); }
        else if (i == N-1 && j == 0) { ins(3); ins(0); ins(M*(N-2)); insLN(M*(N-1)+1); }
        else if (i == N-1 && j == M-1) { ins(3); ins(M-1); ins(M*(N-1)-1); insLN(N*M-2); }
        else if (i == 0) { ins(4); ins(j-1); ins(j+1); ins(M+j); insLN((N-1)*M+j); }
        else if (j == 0) { ins(4); ins((i-1)*M); ins(i*M+1); ins((N-i)*M-1); insLN((i+1)*M); }
        else if (i == N-1) { ins(4); ins(j); ins((N-2)*M+j); ins((N-1)*M+j-1); insLN((N-1)*M+j+1); }
        else if (j == M-1) { ins(4); ins(i*M-1); ins((N-i-1)*M); ins((i+1)*M-2); insLN((i+2)*M-1); }
        else {ins(4); ins((i-1)*M+j); ins(i*M+j-1); ins(i*M+j+1); insLN((i+1)*M+j); }
      }
}

void
on_btPPlane_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, M, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spK1));
  M = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spK2));

  insLN(N*M);

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      {
        if (i == 0 && j == 0) { ins(3); ins(1); ins(M); insLN(N*M-1); }
        else if (i == 0 && j == M-1) { ins(3); ins(M-2); ins(2*M-1); insLN((N-1)*M); }
        else if (i == N-1 && j == 0) { ins(3); ins(M-1); ins(M*(N-2)); insLN(M*(N-1)+1); }
        else if (i == N-1 && j == M-1) { ins(3); ins(0); ins(M*(N-1)-1); insLN(N*M-2); }
        else if (i == 0) { ins(4); ins(j-1); ins(j+1); ins(M+j); insLN(N*M-j-1); }
        else if (j == 0) { ins(4); ins((i-1)*M); ins(i*M+1); ins((N-i)*M-1); insLN((i+1)*M); }
        else if (i == N-1) { ins(4); ins(M-j-1); ins((N-2)*M+j); ins((N-1)*M+j-1); insLN((N-1)*M+j+1); }
        else if (j == M-1) { ins(4); ins(i*M-1); ins((N-i-1)*M); ins((i+1)*M-2); insLN((i+2)*M-1); }
        else {ins(4); ins((i-1)*M+j); ins(i*M+j-1); ins(i*M+j+1); insLN((i+1)*M+j); }
      }
}

void
on_btBipartito_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spB));

  insLN(2*N);

  for (i = 0; i < N; i++)
    {
      ins(N);
      for (j = N; j < 2*N-1; j++)
        ins(j);
      insLN(2*N-1);
    }
  for (i = 0; i < N; i++)
    {
      ins(N);
      for (j = 0; j < N-1; j++)
        ins(j);
      insLN(N-1);
    }
}

void
on_btCricca_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spC));

  insLN(N);

  for (i = 0; i < N; i++)
    {
      ins(N-1);
      for (j = 0; j < N; j++)
        if (i != j)
          ins(j);
    }
}

void
on_btLineare_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, i;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spL));

  insLN(N);

  ins(1); insLN(1);
  for (i = 1; i < N-1; i++) { ins(2); ins(i-1); insLN(i+1); }
  ins(1); insLN(N-2);
}

void
on_btCiclico_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, i;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spT));

  insLN(N);
  
  for (i = 0; i < N; i++) { ins(2); ins((N+i-1)%N); insLN((N+i+1)%N); }
}

int
find(int *uf, int i)
{
  if (uf[i] == i) return i;
  else return (uf[i] = find(uf, uf[i]));
}

void
uni(int *uf, int i, int j)
{
  i = find(uf, i);
  j = find(uf, j);
  if (i < j)
    uf[j] = i;
  else
    uf[i] = j;
}

void
on_btCasuale_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, i, j, messi;
  int **lista, *tmp, *uf;
  double P;
  
  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spR));
  P = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(win.spRP));
  
  lista = myalloc(sizeof(int*) * N);
  for (i = 0; i < N; i++)
    {
      lista[i] = myalloc(sizeof(int) * (i+1));
      lista[i][0] = 0;
    }
  tmp = myalloc(sizeof(int) * N);
  uf = myalloc(sizeof(int) * N);
  for (i = 0; i < N; i++)
    uf[i] = i;
  insLN(N);
  
  
  for (i = 0; i < N; i++)
    {
      messi = 0;
      for (j = i+1; j < N; j++)
        {
          if (randouble(0, 1) < P)
            {
              tmp[messi] = j;
              lista[j][lista[j][0]+1] = i;
              lista[j][0]++;
              messi++;
              uni(uf, i, j);
            }
        }
      if (i == 0 && find(uf, N-1) != 0)
        {
          tmp[messi++] = N-1;
          lista[N-1][0]++;
          lista[N-1][lista[N-1][0]] = 0;
          uni(uf, 0, N-1);
        }
      if (find(uf, i) != 0)
        {
          lista[i][0]++;
          lista[i][lista[i][0]] = N-1;
          lista[N-1][0]++;
          lista[N-1][lista[N-1][0]] = i;
          uni(uf, i, N-1);
        }
      insLN(messi + lista[i][0]);
      for (j = 1; j <= lista[i][0]; j++)
        ins(lista[i][j]);
      for (j = 0; j < messi; j++)
        ins(tmp[j]);
    }
    
  for(i = 0; i < N; i++)
    free(lista[i]);
  free(lista);
  free(tmp);
  free(uf);
}

void
on_btIpercubo_clicked(GtkWidget *widget, gpointer user_data)
{
  GtkTextIter s, e;
  gint N, i, j;

  gtk_text_buffer_get_bounds(win.bufGrafo, &s, &e);
  gtk_text_buffer_delete(win.bufGrafo, &s, &e);
  N = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(win.spI));

  insLN(pow(2, N));

  for (i = 0; i < pow(2, N); i++)
    {
      ins(N);
      for (j = 0; j < N; j++)
        ins(i ^ (1 << j));
    }
}

/*****************************************************
 * Main
 *****************************************************/

void
create_window(void)
{
  GladeXML *xml;
  xml = glade_xml_new("NetViz.glade", NULL, NULL);

  win.w = win.h = 600;
  
  win.window = glade_xml_get_widget(xml, "window");
  win.btCentra = glade_xml_get_widget(xml, "btCentra");
  win.btNuovo = glade_xml_get_widget(xml, "btNuovo");
  win.btEsci = glade_xml_get_widget(xml, "btEsci");
  win.daMain = glade_xml_get_widget(xml, "daMain");
  win.daFirst = glade_xml_get_widget(xml, "daFirst");
  win.daSecond = glade_xml_get_widget(xml, "daSecond");
  win.cbFirst1 = glade_xml_get_widget(xml, "cbFirst1");
  win.cbFirst2 = glade_xml_get_widget(xml, "cbFirst2");
  win.cbSecond1 = glade_xml_get_widget(xml, "cbSecond1");
  win.cbSecond2 = glade_xml_get_widget(xml, "cbSecond2");
  win.rbHK1 = glade_xml_get_widget(xml, "rbHK1");
  win.rbHK2 = glade_xml_get_widget(xml, "rbHK2");
  win.rbT = glade_xml_get_widget(xml, "rbT");
  win.lbInfo = glade_xml_get_widget(xml, "lbInfo");

  win.btLenzuolo = glade_xml_get_widget(xml, "btLenzuolo");
  win.btLenzuoloApp = glade_xml_get_widget(xml, "btLenzuoloApp");
  win.btCilindro = glade_xml_get_widget(xml, "btCilindro");
  win.btMoebius = glade_xml_get_widget(xml, "btMoebius");
  win.btToro = glade_xml_get_widget(xml, "btToro");
  win.btKlein = glade_xml_get_widget(xml, "btKlein");
  win.btBipartito = glade_xml_get_widget(xml, "btBipartito");
  win.btCricca = glade_xml_get_widget(xml, "btCricca");
  win.btLineare = glade_xml_get_widget(xml, "btLineare");
  win.btCiclico = glade_xml_get_widget(xml, "btCiclico");
  win.btCasuale = glade_xml_get_widget(xml, "btCasuale");
  win.btIpercubo = glade_xml_get_widget(xml, "btIpercubo");

  win.spL1 = glade_xml_get_widget(xml, "spL1");
  win.spL2 = glade_xml_get_widget(xml, "spL2");
  win.spLA1 = glade_xml_get_widget(xml, "spLA1");
  win.spLA2 = glade_xml_get_widget(xml, "spLA2");
  win.spC1 = glade_xml_get_widget(xml, "spC1");
  win.spC2 = glade_xml_get_widget(xml, "spC2");
  win.spM1 = glade_xml_get_widget(xml, "spM1");
  win.spM2 = glade_xml_get_widget(xml, "spM2");
  win.spT1 = glade_xml_get_widget(xml, "spT1");
  win.spT2 = glade_xml_get_widget(xml, "spT2");
  win.spK1 = glade_xml_get_widget(xml, "spK1");
  win.spK2 = glade_xml_get_widget(xml, "spK2");
  win.spB = glade_xml_get_widget(xml, "spB");
  win.spC = glade_xml_get_widget(xml, "spC");
  win.spL = glade_xml_get_widget(xml, "spL");
  win.spT = glade_xml_get_widget(xml, "spT");
  win.spR = glade_xml_get_widget(xml, "spR");
  win.spRP = glade_xml_get_widget(xml, "spRP");
  win.spI = glade_xml_get_widget(xml, "spI");

  win.txtGrafo = glade_xml_get_widget(xml, "txtGrafo");
  win.btOK = glade_xml_get_widget(xml, "btOK");
  win.nuovo = glade_xml_get_widget(xml, "nuovo");
  win.bufGrafo = gtk_text_view_get_buffer(GTK_TEXT_VIEW(win.txtGrafo));

  win.daFirstActive = win.daSecondActive = 0;
  win.daFirstPoint.X = win.daSecondPoint.X = 1;
  win.daFirstPoint.Y = win.daSecondPoint.Y = 0;
  win.daQuadrante1.X = 50;
  win.daQuadrante1.Y = 50;
  win.daQuadranteC.X = win.daQuadranteC.Y = 75;

  g_signal_connect (win.daMain, "expose_event", G_CALLBACK (on_daMain_expose_event), NULL);
  g_signal_connect (win.daMain, "motion_notify_event", G_CALLBACK (on_daMain_motion_notify_event), NULL);
  g_signal_connect (win.daMain, "button_press_event", G_CALLBACK (on_daMain_button_press_event), NULL);
  g_signal_connect (win.daFirst, "expose_event", G_CALLBACK (on_daFirst_expose_event), NULL);
  g_signal_connect (win.daFirst, "button_press_event", G_CALLBACK (on_daFirst_button_press_event), NULL);
  g_signal_connect (win.daSecond, "expose_event", G_CALLBACK (on_daSecond_expose_event), NULL);
  g_signal_connect (win.daSecond, "button_press_event", G_CALLBACK (on_daSecond_button_press_event), NULL);
  g_signal_connect (win.window, "destroy", G_CALLBACK (gtk_main_quit), NULL);
  g_signal_connect (win.btCentra, "clicked", G_CALLBACK (on_btCentra_clicked), NULL);
  g_signal_connect (win.btNuovo, "clicked", G_CALLBACK (on_btNuovo_clicked), NULL);
  g_signal_connect (win.btEsci, "clicked", G_CALLBACK (gtk_main_quit), NULL);
  g_signal_connect (win.cbFirst1, "changed", G_CALLBACK (on_eigen_changed), NULL);
  g_signal_connect (win.cbFirst2, "changed", G_CALLBACK (on_eigen_changed), NULL);
  g_signal_connect (win.cbSecond1, "changed", G_CALLBACK (on_eigen_changed), NULL);
  g_signal_connect (win.cbSecond2, "changed", G_CALLBACK (on_eigen_changed), NULL);
  g_signal_connect (win.rbHK1, "toggled", G_CALLBACK (on_group_changed), NULL);
  g_signal_connect (win.rbHK2, "toggled", G_CALLBACK (on_group_changed), NULL);
  g_signal_connect (win.rbT, "toggled", G_CALLBACK (on_group_changed), NULL);

  g_signal_connect (win.btOK, "clicked", G_CALLBACK (on_btOK_clicked), NULL);
  g_signal_connect (win.btLenzuolo, "clicked", G_CALLBACK (on_btLenzuolo_clicked), NULL);
  g_signal_connect (win.btLenzuoloApp, "clicked", G_CALLBACK (on_btLenzuoloApp_clicked), NULL);
  g_signal_connect (win.btCilindro, "clicked", G_CALLBACK (on_btCilindro_clicked), NULL);
  g_signal_connect (win.btMoebius, "clicked", G_CALLBACK (on_btMoebius_clicked), NULL);
  g_signal_connect (win.btToro, "clicked", G_CALLBACK (on_btToro_clicked), NULL);
  g_signal_connect (win.btKlein, "clicked", G_CALLBACK (on_btKlein_clicked), NULL);
  g_signal_connect (win.btBipartito, "clicked", G_CALLBACK (on_btBipartito_clicked), NULL);
  g_signal_connect (win.btCricca, "clicked", G_CALLBACK (on_btCricca_clicked), NULL);
  g_signal_connect (win.btLineare, "clicked", G_CALLBACK (on_btLineare_clicked), NULL);
  g_signal_connect (win.btCiclico, "clicked", G_CALLBACK (on_btCiclico_clicked), NULL);
  g_signal_connect (win.btCasuale, "clicked", G_CALLBACK (on_btCasuale_clicked), NULL);
  g_signal_connect (win.btIpercubo, "clicked", G_CALLBACK (on_btIpercubo_clicked), NULL);

  gtk_combo_box_set_active(GTK_COMBO_BOX(win.cbFirst1), 0);
  gtk_combo_box_set_active(GTK_COMBO_BOX(win.cbFirst2), 0);
  gtk_combo_box_set_active(GTK_COMBO_BOX(win.cbSecond1), 1);
  gtk_combo_box_set_active(GTK_COMBO_BOX(win.cbSecond2), 0);  
}


void moltiplicaSelfVeloce(double **X, int stm, int stn, int m, int n, int rm, int rn, double **R);
void moltiplicaLento(double **X, int m, int n, int stm1, int stn1, int rm1, int rn1,
                     int stm2, int stn2, int rm2, int rn2, double **R);

int
main (int argc, char *argv[])
{
  model.timeBegin = time(NULL);
  srand(0);
  gtk_init(&argc, &argv);

#ifdef MEMDEBUG
  win.allocati = 0;
#endif

  create_window();
  leggi("1 0", HK1);
  gtk_main();
  return 0;
}
