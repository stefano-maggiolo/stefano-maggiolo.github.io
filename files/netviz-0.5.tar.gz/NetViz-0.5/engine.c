/*
 * engine.c
 *
 * Copyright (C) 2007 Stefano Maggiolo <maggiolo@mail.dm.unipi.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#define _GNU_SOURCE
#include <gtk/gtk.h>
#include <cairo.h>
#include <cairo-xlib.h>
#include <gdk/gdkx.h>
#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>

#include "NetViz.h"

extern Model model;
extern Windowinfo win;

/*****************************************************
 * Utilità
 *****************************************************/

time_t
stampaTempo(char *s)
{
  time_t t = time(NULL);
  printf("[%ld] %s\n", t - model.timeBegin, s);
  return t;
}

void *
myalloc(size_t byte)
{
  void *p = malloc(byte);
  assert(p);
#ifdef MEMDEBUG
  win.allocati += byte;
  printf("Allocati %d byte.\n", win.allocati);
#endif
  return p;
}

inline int
min(int a, int b)
{
  return a > b? b: a;
}

double
randouble(double a, double b)
{
  return ((double)rand())/RAND_MAX * (b-a) + a;
}

double sqr(double a) { return a*a; }
double cube(double a) { return a*a*a; }

double
ndist(double *p, int n)
{
  double s = 0;
  for (; n > 0; n--)
    s += p[n-1]*p[n-1];
  return sqrt(s);
}

void
ndiff(double *a, double *b, double *c, int n)
{
  for (; n > 0; n--)
    c[n-1] = a[n-1] - b[n-1];
}

void
nsomma(double *a, double *b, double *c, int n)
{
  for (; n > 0; n--)
    c[n-1] = a[n-1] + b[n-1];
}

void
nprod_s(double *a, double b, double *c, int n)
{
  for (; n > 0; n--)
    c[n-1] = a[n-1] * b;
}

double
nprod_scal(double *a, double *b, int n)
{
  double s = 0;
  for (; n > 0; n--)
    s += a[n-1] * b[n-1];
  return s;
}

void
nvers(double *a, double *b, int n)
{
  double d = ndist(a, n);
  nprod_s(a, 1/d, b, n);
}

void
ncopy(double *a, double *b, int n)
{
  for (; n > 0; n--)
    b[n-1] = a[n-1];
}

/*****************************************************
 * Motore
 *****************************************************/

inline int getDistanza(int i, int j)
{
  if (i >= j) return (double)model.distanze[i][j];
  else return (double)model.distanze[j][i];
}

inline void setDistanza(int i, int j, double d)
{
  if (i >= j) model.distanze[i][j] = (int)d;
  else model.distanze[j][i] = (int)d;
}

double
BFS(int start)
{
  int i;
  int *q = myalloc(sizeof(int) * model.n), qs = 0, qe = 1;
  int *v = myalloc(sizeof(int) * model.n);
  double summa = 0;

  for (i = 0; i < model.n; i++) v[i] = 0;
  v[start] = 1;
  q[0] = start;
  while (qe > qs)
    {
      int curr = q[qs++];
      for (i = 0; i < model.d[curr]; i++)
        if (v[model.e[curr][i]] == 0)
          {
            double d = getDistanza(start, curr) + 1;
            setDistanza(start, model.e[curr][i], d);
            summa += d;
            q[qe++] = model.e[curr][i];
            v[model.e[curr][i]] = 1;
          }
    }
  free(q);
  free(v);
  return summa;
}

int
scegli(int i)
{
  int j, maxi = -1;
  /* per non far scegliere sempre i primi in caso di molti nodi con punteggio uguale */
  int start = (int)randouble(0, model.n - EPS); 
  double max = 0;
  static double *tmp;
  if (i == 0)
    {
      tmp = myalloc(sizeof(double) * model.n);
      for (j = 0; j < model.n; j++)
        tmp[j] = BIG;
      return 0;
    }
  
  for (j = 0; j < model.n; j++)
    {
      double d;
      int k = (j + start) % model.n;
      if (model.scelti[k]) continue;
      d = getDistanza(model.listaScelti[i-1], k);
      if (d < tmp[k]) tmp[k] = d;
      if (maxi == -1 || tmp[k] > max)
        {
          max = tmp[k];
          maxi = k;
        }
    }

  if (i == model.m - 1) free(tmp);
  return maxi;
}

void
posiziona(int modo)
{
  if (modo == HK1 || modo == HK2)
    {
      int i, j;
      
      for (i = 0; i < model.m; i++)
        {
          double media;
          model.listaScelti[i] = scegli(i);
          model.scelti[model.listaScelti[i]] = 1;
#ifdef DEBUG
          printf("Autovalore scelto: %d\n", model.listaScelti[i]);
#endif
          media = model.sommaDistanze[model.listaScelti[i]] / model.n;
          for (j = 0; j < model.n; j++)
            model.M[i][j] = getDistanza(model.listaScelti[i], j) - media;
        }
    }

  else if (modo == TORG)
    {
      int i,j, k,l;
      double *col = malloc(sizeof(double) * model.n);
      double tmp = 0;
      for (k = 0; k < model.n; k++)
        {
          col[k] = 0;
          for (l = 0; l < model.n; l++)
            {
              tmp += sqr(getDistanza(k, l)) / model.n;
              col[k] += sqr(getDistanza(k, l));
            }
        }
      
      for (i = 0; i < model.n; i++)
        for (j = i; j < model.n; j++)
          model.M[j][i] = model.M[i][j] = (col[i] + col[j] - tmp - model.n * sqr(getDistanza(i, j))) / (2*model.n);
      free(col);
      for (i = 0; i < model.n; i++)
        {
          double summa = 0;
          for (j = 0; j < model.n; j++)
            summa += model.M[i][j];
          summa /= model.n;
          for (j = 0; j < model.n; j++)
            model.M[i][j] -= summa;
        }
    }
}

void
applica(double *a, double *b)
{
  int i, j;
  double *v = malloc(sizeof(double) * model.n);
  /* (MM^t) x = M(M^t x)! e tutto e` piu` veloce. (grazie a Giuseppe Ottaviano) */
  for (i = 0; i < model.n; i++)
    {
      v[i] = 0;
      for (j = 0; j < model.m; j++)
        v[i] += a[j] * model.M[j][i];
    }
  for (i = 0; i < model.m; i++)
    {
      b[i] = 0;
      for (j = 0; j < model.n; j++)
        b[i] += v[j] * model.M[i][j];
    }
  free(v);
}
        
void
autovalori(void)
{
  int i, j;
  double *new = malloc(sizeof(double) * model.m);
  double *tmp = malloc(sizeof(double) * model.m);
  for (i = 0; i < min(EIGEN, model.m); i++)
    {
      double ps = 0;
      int t = 0;

      for (j = 0; j < model.m; j++)
        new[j] = randouble(-1, 1);
      nvers(new, new, model.m);

      do
        {
          t++;
          ncopy(new, model.eigen[i], model.m);
          for (j = 0; j < i; j++)
            {
              nprod_s(model.eigen[j], nprod_scal(model.eigen[j], model.eigen[i], model.m), tmp, model.m);
              ndiff(model.eigen[i], tmp, model.eigen[i], model.m);
            }

          applica(model.eigen[i], new);
          nvers(new, new, model.m);
          nvers(model.eigen[i], model.eigen[i], model.m);
          ps = nprod_scal(new, model.eigen[i], model.m);
#ifdef DEBUG
          printf("P[%d]: %.10lf %.2lf %.2lf %.2lf %.2lf\n", i, ps, new[0], new[1], model.eigen[i][0], model.eigen[i][1]);
#endif          
        } while(ps < 1 - EPS && t < MAX_ITERAZIONI);
      if (i > 0 && isnan(new[0]))
        ncopy(model.eigen[i-1], model.eigen[i], model.m);
      else
        ncopy(new, model.eigen[i], model.m);
      model.eigenWarning[i] = (t >= MAX_ITERAZIONI || isnan(new[0]));
    }
  free(new);
  free(tmp);
}

void
liberamodel(void)
{
  int i;
  for (i = 0; i < model.m; i++)
    free(model.M[i]);
  free(model.M);
  free(model.P);
  free(model.scelti);
  for (i = 0; i < EIGEN; i++)
    free(model.eigen[i]);
  free(model.eigen);
}

void
esegui(int how)
{
  int i;
#ifdef DEBUG
  int j;
#endif
  int t1, t2, t3;
  char info[500];
  char eigenWarn[20];

  if (how == HK1 && model.n > HK1_PIVOT) model.m = HK1_PIVOT;
  else model.m = model.n;

  model.M = myalloc(sizeof(double*) * model.m);
  for (i = 0; i < model.m; i++)
    model.M[i] = myalloc(sizeof(double) * model.n);
  
  model.eigen = myalloc(EIGEN * sizeof(double*));
  for (i = 0; i < EIGEN; i++)
    model.eigen[i] = myalloc(model.m * sizeof(double));

  model.P = myalloc(sizeof(Point) * model.n);
  model.listaScelti = myalloc(sizeof(int) * model.m);
  model.scelti = myalloc(sizeof(int) * model.n);
  for (i = 0; i < model.n; i++)
    model.scelti[i] = 0;

  stampaTempo("Sto posizionando i nodi in dimensione alta...");
  t1 = time(NULL);
  posiziona(how);
  stampaTempo("Fatto");

#ifdef DEBUG
  printf("M:={\n");
  for (i = 0; i < model.m; i++)
    {
      printf("{");
      for (j = 0; j < model.n; j++)
        printf("%.2lf, ", model.M[i][j]);
      printf("}\n");
    }
  printf("}\n");
#endif

  stampaTempo("Sto calcolando un po' di autovalori...");
  t2 = time(NULL);
  autovalori();
  stampaTempo("Fatto");

#ifdef DEBUG
  printf("Eigen:\n");
  for (i = 0; i < min(EIGEN, model.m); i++)
    {
      for (j = 0; j < model.m; j++)
        printf("%.2lf, ", model.eigen[i][j]);
      printf("\n");
    }
#endif
  t3 = time(NULL);

  eigenWarn[0] = 0;
  for (i = 0; i < EIGEN; i++)
    {
      if (model.eigenWarning[i])
        sprintf(info, "%d ", i+1);
      else
        info[0] = 0;
      strcat(eigenWarn, info);
    }
  sprintf(info, "Nodi: %d\nDimensione: %d\nTempo per il calcolo delle distanze: %d s\nTempo per il posizionamento: %d s\nTempo per il calcolo degli autovalori: %d s\nAutovettori mal calcolati: %s", model.n, model.m, model.timeBFS, t2 - t1, t3 - t2, eigenWarn);
  gtk_label_set_text(GTK_LABEL(win.lbInfo), info);
}

void
leggi(char *buffer, int how)
{
  int i, j;
  time_t t1;
  FILE *f = fmemopen(buffer, strlen(buffer), "r");
  assert(f != NULL);
  
  stampaTempo("Sto leggendo l'input...");
  for (i = 0; i < EIGEN; i++)
    model.eigenScelti[0][i] = model.eigenScelti[1][i] = 0;
  model.eigenScelti[0][0] = model.eigenScelti[1][1] = 1;
  on_eigen_changed(NULL, NULL);

  
  fscanf(f, "%d", &(model.n));
  model.e = myalloc(model.n * sizeof(int*));
  model.d = myalloc(model.n * sizeof(int));
  model.distanze = myalloc(sizeof(int*) * model.n);
  for (i = 0; i < model.n; i++)
    {
      model.distanze[i] = myalloc(sizeof(int) * (i+1));
      for (j = 0; j <= i; j++)
        model.distanze[i][j] = 0;

      fscanf(f, "%d", &(model.d[i]));
      model.e[i] = myalloc(sizeof(int) * model.d[i]);
      for (j = 0; j < model.d[i]; j++)
        fscanf(f, "%d", &(model.e[i][j]));
    }

  model.sommaDistanze = myalloc(sizeof(double) * model.n);
  stampaTempo("Fatto");

  stampaTempo("Sto calcolando le distanze...");
  t1 = time(NULL);
  for (i = 0; i < model.n; i++)
    model.sommaDistanze[i] = BFS(i);
  model.timeBFS = time(NULL) - t1;
  stampaTempo("Fatto");
  esegui(how);
}
